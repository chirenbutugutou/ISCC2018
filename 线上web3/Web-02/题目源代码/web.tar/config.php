<?php  
function get_contents($img)
{
	if(strpos($img,'jpg') !== false)
	{
		return file_get_contents($img);
	}
	else
	{
		header('Content-Type: text/html');
		return file_get_contents($img);
	}
}
?>