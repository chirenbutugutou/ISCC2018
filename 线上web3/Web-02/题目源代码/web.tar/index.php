<img src="show.php?img=1.jpg">
