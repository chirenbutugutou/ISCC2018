<?php
$flag="flag{a39f9a1ff7eb4b3ab8a6a21b2ce111b4}";
?>