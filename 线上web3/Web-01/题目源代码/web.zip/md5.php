<?php

if(isset($_POST['username'])&isset($_POST['password'])){
    if($_POST['username']==""||$_POST['password']==""){
            echo "用户名或密码不能为空";
    }
    else{
        $username = $_POST['username'];
        $password = $_POST['password'];
    }
}
else{
    $username="hello";
    $password="hello";

}
if(md5($password) == md5('QNKCDZO')){
    echo "<a href='no_md5.php?a=hello'>click_here!</a>";
    $_COOKIE['flag']="flag{xxx}";
}
else{

    echo "try!";
}
?>