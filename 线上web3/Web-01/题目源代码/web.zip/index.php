
<html>
<body>
<form action="md5.php"  method="post" >
    用户名:<input type="text" name="username"/>
    密码:<input type="password" name ="password"/>
    <input type="submit" >
</body>
</html>
<?php
if(isset($_POST['username'])&isset($_POST['password'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
}
else{
    $username="hello";
    $password="hello";
}
if(md5($password) == 0){
    echo "xxxxx";
}


show_source(__FILE__);
?>