<?php
highlight_file('2.php');
$flag='{iscc_ef3w5r5tw_5rg5y6s3t3}';
if (isset($_GET['password'])) {  
    if (strcmp($_GET['password'], $flag) == 0)  
        die('Flag: '.$flag);  
    else  
        print 'Invalid password';  
}  
?>