<?php

function GetIP(){
if(!empty($_SERVER["HTTP_CLIENT_IP"]))
	$cip = $_SERVER["HTTP_CLIENT_IP"];
else if(!empty($_SERVER["REMOTE_ADDR"]))
	$cip = $_SERVER["REMOTE_ADDR"];
else
	$cip = "0.0.0.0";
return $cip;
}

$GetIPs = GetIP();
if ($GetIPs=="127.0.0.1"){
echo "Great! flag{iscc_059eeb8c0c33eb62}";
}
else{
echo "错误！你的IP不是本机ip！";
}
?>