<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
	<title>welcome</title>
	<link rel="stylesheet" href="app.css">  
	<script src="app.js"></script>
</head>
<body>
<?php
$list = array('tables',',','&','and','ascii','ord','substr','hex','columns');

$DB_USER = 'root';
$DB_PWD = 'secret';
$DB_HOST = 'localhost';
$DB_NAME = 'sqli_database';

$conn=new mysqli($DB_HOST,$DB_USER,$DB_PWD) or die("连接失败");
$conn->select_db($DB_NAME) or die("数据连接失败");
$conn->query("SET NAMES 'utf8'") or die("设置字符失败");

session_start();
if(isset($_GET['op']) && $_GET['op'] == 'logout') unset($_SESSION['admin']);

$username = isset($_POST["username"])?$_POST["username"]:'';
$password = isset($_POST["password"])?$_POST["password"]:'';
if ($username and $password) {
    $password = md5($password);
    if($username == 'admin') {
        $sql = "select * from user where username='$username' and pass='$password'";
        $result = $conn->query($sql);
        if($result && $result->num_rows) {
            $_SESSION['admin'] = $username;
        } else {
            die("密码错误");
        }
    } else {
        $sql = "select * from user where username='$username' and pass='$password'";
        $result = $conn->query($sql);
        if(check_value($list, $username) && $result && $result = $result->fetch_object()) {
            echo "normal user: ".$username;
        } else {
            echo "账号或密码错误";
        }
    }
}
if(isset($_SESSION['admin'])) {
    $id = check_value($list, isset($_GET["id"])?$_GET["id"]:1);
    $sql = "select * from news where id = $id";
    $result = $conn->query($sql);
echo <<<html
<a href='?op=logout'>logout</a>
<br>
<form class="form-horizontal col-sm-10" role="form">
  <div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">id</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" name="id" value="1">
    </div>
    <button type="submit" class="btn btn-default">提交</button>
  </div>
</form>
<table class="table">
  <caption>flag在另一个字段</caption>
  <thead>
    <tr>
      <th>id</th>
      <th>标题</th>
      <th>内容</th>
      <th>时间</th>
      <th>备注</th>
    </tr>
  </thead>
  <tbody>
html;
    if($result && $result->num_rows) {
        while($res = $result->fetch_object()) {
            echo "<tr><td>{$res->id}</td><td>{$res->title}</td><td>{$res->text}</td><td>{$res->date}</td><td>{$res->note}</td></tr>";
        }
    } else {
        echo "<tr><td></td><td></td><td></td><td></td></tr>";
    }
    echo "</tbody>
    </table>";
} else {
echo <<<html
<div class="container">
    <div class="row" style="margin-top:12%;">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="">
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">username</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="username" value="" required autofocus>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>
                            <div class="col-md-6">
                                <input type="password" class="form-control" name="password" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
html;
}
function check_value($list, $value) {
    foreach ($list as $k => $v) {
        if(stripos($value, $v));
    }
    return $value;
}
?>
</body>
</html>